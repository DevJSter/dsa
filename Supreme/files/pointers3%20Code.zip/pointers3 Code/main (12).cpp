#include <iostream>
using namespace std;

// void solve(int& num ) {
//         num  = 50;
// } 

// void solve(int* val) {
//         *val = *val + 1;
// }

// void solve(int*& p) {
//         p = p + 1;
// }

int main() {

        // int a = 5;
        // solve(a) ;

        // cout << a << endl;

        // int a = 12;
        // int *p = &a;
        // solve(p);
        // cout << a << endl;

        // int a = 5;
        // int* p = &a;

        // cout << "before " << p << endl; 
        // solve(p);
        // cout << "After " << p << endl;



  return 0;
}