#include <iostream>
#include<vector>
using namespace std;

int main() {
  vector<int> v(10);
  cin >> v[0];
  cout << v[0] << " ";

  return 0;
}